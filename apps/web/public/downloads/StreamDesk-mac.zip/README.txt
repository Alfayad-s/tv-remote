StreamDesk Desk (macOS)
=======================

1. Install Node.js 22+ from https://nodejs.org if you do not have it.
2. Double-click "Start StreamDesk Desk.command".
3. Open http://localhost:8790/ in Safari/Chrome to arrange apps + icons.
4. On your phone, open the StreamDesk app (or website remote), enter this Mac's IP and the PIN.

The desk agent listens on port 8790 on your Wi-Fi.
